<?php
namespace easys\wechat;

use easys\web\response;
use easys\web\pdoobj;
use easys\web\oauth;
use easys\web\logger;

class transfer extends oauth{
	
	private $pdo = null;
	
	protected $apierrorcode;
	//www.gzfesco.cn/wechat/transfer/authorize
	public function __construct($database,$apierrorcode) {

		header('Access-Control-Allow-Origin:*');
		
		$this->pdo = pdoobj::getInstance($database);
		
		$this->apierrorcode = $apierrorcode;
		
		parent::__construct($this->pdo);
				
		//header('Content-type: application/json');
	}
	
	public function __destruct() {
		
	}
	
	public function authorize() {
		
		if (!isset($_GET["code"])){
			
			$redirect_url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			
			//snsapi_userinfo,snsapi_base,123为自己带的参数，传给微信又传回来
			
			$jumpurl = $this->oauth2_authorize($redirect_url, "snsapi_userinfo", 222);
			
			Header("Location: $jumpurl");
			
			exit();
		
		}else{
			p(1);
			$openid_token = $this->oauth2_access_token($_GET["code"]);//通过code获取openid和accesstoken
			
			$openid = $openid_token['openid'];
			
			$access_token = $openid_token['access_token'];
			
			//$info = $this->get_user_info($openid);//调用获取用户信息的接口
			
			$userinfo = $this->oauth2_get_user_info($access_token, $openid);//调用微信授权获取用户信息的接口 
			
			
		    try{
				
				p($userinfo);
				
				//$turl = 'http://'.$_GET['url']."&openid={$openid}&nickname={$userinfo['nickname']}&headimgurl={$userinfo['headimgurl']}";
				
				//Header("Location: $turl");
							
				exit;
				
		    }catch (PDOException $e) {
				
				echo response::json(40000,$this->apierrorcode['40000']);
				
				//echo "Error!: " . $e->getMessage() . "<br/>";
				
				//$this->pdo->rollback();
				
				exit;
				
		    }
			
			
		}
		
		
	}
	//扫码关注推送event后，默认在原先开始的地方发起一个get请求,到这个方法来
	public function scancode(){
		
		$arr = file_get_contents("php://input");
		
		$array = json_decode($arr,true);
		
		$openid = $array[0]['openid'];
		$openid = 'oZPt5t_bNafqeH-IFVIi_ewteOps';
		
		$res = $this->get_user_info($openid);
		//{$array[0]['openid']}','{$res['headimgurl']}','{$res['nickname']}
		
		$url = 'http://www.gzfesco.cn/wechat/transfer/scancode';
				
		//$this->http_request($url);
		
	}
	

	//通过微信制作扫码关注页面
	public function getqr(){
	//http://www.gzfesco.cn/wechat/transfer/url/?str=2	
	    $result = $this->pdo->execall('select * from wechat where id = 1');
	   
	    $appid = $result[0]["APPID"];
	   
	    $appsecret = $result[0]["APPSECRET"];
       
	    $access_token = $result[0]["access_token"];
		
		if(!isset($_GET['str'])){
			
			echo response::json(40005,$this->apierrorcode['40005']);
			
			exit;
		
		}else{
			
			$str = bob_input($_GET['str']);
		
			//QR_LIMIT_SCENE为整形，QR_LIMIT_STR_SCENE为字符串
			$qrcode = '{"action_name": "QR_LIMIT_SCENE", "action_info": {"scene": {"scene_id": '.$str.'}}}';
			//$qrcode = '{"action_name": "QR_LIMIT_STR_SCENE", "action_info": {"scene": {"scene_str": '."\"$str\"".'}}}';

			$url = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=$access_token";
			
			$result = $this->http_request($url, $qrcode);
			
			$jsoninfo = json_decode($result, true);
			
			//拿到ticket后可以换取2维码
			$ticket = $jsoninfo["ticket"];
		   
			$url = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=".urlencode($ticket);
			
			$imageInfo = $this->downloadWeixinFile($url);
			
			$filename = 'qr'.DIRECTORY_SEPARATOR.$str.".jpg";
			
			$local_file = fopen($filename, 'w');
			
			fwrite($local_file, $imageInfo["body"]);
			
			fclose($local_file);
								
		}
		
	}
	
	
	//http请求
	public function http_request($url, $data = null)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)){
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);
		return $output;
	}

	//下载文件
	public function downloadWeixinFile($url)
	{
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_NOBODY, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$package = curl_exec($ch);
		$httpinfo = curl_getinfo($ch);
		curl_close($ch);
		$imageAll = array_merge(array('body' =>$package), array('header' =>$httpinfo));
		return $imageAll;
	}
	
	//生成长度16的随机字符串
    public function createNonceStr($length = 16) {
    
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		
        $str = "";
        
		for ($i = 0; $i < $length; $i++) {
              $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        
		return $str;
    }
	
	//获得js签名包
	public function getSignPackage() {
		
		$jsapiTicket = $this->pdo->execall("select * from wechat where id =1 ");
		
		$appid = $jsapiTicket[0]['APPID'];
		
		$jsapiTicket = $jsapiTicket[0]['jsapi_ticket'];
		
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		
		//$url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		
		$url = bob_input($_GET['url']);
		
		$url = htmlspecialchars_decode($url);
		
		$timestamp = time();
		
		$nonceStr = $this->createNonceStr();
		
		$string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";
		
		$signature = sha1($string);
		
		$signPackage = array(
						 "appId"     => $appid,
						 "nonceStr"  => $nonceStr,
						 "timestamp" => $timestamp,
						 "url"       => $url,
						 "signature" => $signature,
						 "rawString" => $string
						);					
		
		echo response::json(20000,$this->apierrorcode['20000'],[$signPackage]);
		
		exit;

	}
	
	public function third_authorize() {
		
		if (!isset($_GET["code"])){
			
			$redirect_url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			
			//snsapi_userinfo,snsapi_base,123为自己带的参数，传给微信又传回来
			
			$jumpurl = $this->third_oauth2_authorize($redirect_url, "snsapi_base", 222,'appid');
			
			Header("Location: $jumpurl");
			
			exit();
		
		}else{
			//这里传当当饭堂的公众号appid
			$openid_token = $this->third_oauth2_accesstoken($_GET["code"],'');//通过code获取openid和accesstoken
			
			$openid = $openid_token['openid'];
			
			$access_token = $openid_token['access_token'];
			
			//$info = $this->get_user_info($openid);//调用获取用户信息的接口
			
			$userinfo = $this->third_oauth2_getuserinfo($access_token, $openid);//调用微信授权获取用户信息的接口 
			
			
		    try{
				
				p($userinfo);
				
				//$turl = 'http://'.$_GET['url']."&openid={$openid}&nickname={$userinfo['nickname']}&headimgurl={$userinfo['headimgurl']}";
				
				//Header("Location: $turl");
							
				exit;
				
		    }catch (PDOException $e) {
				
				echo response::json(40000,$this->apierrorcode['40000']);
				
				//echo "Error!: " . $e->getMessage() . "<br/>";
				
				//$this->pdo->rollback();
				
				exit;
				
		    }
			
			
		}
		
		
	}
	
	
	

}


?>