<?php
namespace easys\wechat;

use easys\web\response;
use easys\web\pdoobj;
use easys\web\oauth;
use easys\web\logger;


class index3{
	
	private $pdo = null;
	
	protected $apierrorcode;
	
	
	//构造函数获取第三方平台component_access_token
	public function __construct($database,$apierrorcode) {
		
		header('Access-Control-Allow-Origin:*');
		
		//origin-when-cross-origin
		
		//header('Referrer-Policy: origin-when-cross-origin');
		
		$this->pdo = pdoobj::getInstance($database);
		
		$this->apierrorcode = $apierrorcode;
		
		$result = $this->pdo->execall('select * from wechat where id = 2');
	   
	    $this->component_appid = $result[0]['APPID'];
	   
	    $this->component_appsecret = $result[0]['APPSECRET'];
		
		$this->token = $result[0]['token'];
		
		$this->EncodingAESKey = $result[0]['EncodingAESKey'];
		//前面这4项包括appid等，和微信公众号复用栏位
		$this->component_verify_ticket = $result[0]['component_verify_ticket'];
		
		$this->component_expires_time = $result[0]['component_expires_time'];
		
		$this->component_access_token = $result[0]['component_access_token'];
		
	}
	
	public function __destruct() {
		
	}
	
	//授权页网址
    public function component_login_page($pre_auth_code, $redirect_uri)
    {
        $url = "https://mp.weixin.qq.com/cgi-bin/componentloginpage?component_appid=".$this->component_appid."&pre_auth_code=".$pre_auth_code."&redirect_uri=".$redirect_uri;
        return $url;
    }
	
	//获取微信每隔10分钟post过来的component_verify_ticket,其实对应着微信接口9
	public function index(){
		
		$signature  = $_GET['signature'];
		$timestamp  = $_GET['timestamp'];
		$nonce = $_GET['nonce'];
		$encrypt_type = $_GET['encrypt_type'];
		$msg_signature = $_GET['msg_signature'];
		//$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
		$postStr= file_get_contents("php://input");

		//解密
		$pc = new WXBizMsgCrypt($this->token, $this->EncodingAESKey, $this->component_appid);				
		
		$decryptMsg = "";  //解密后的明文
		$errCode = $pc->DecryptMsg($msg_signature, $timestamp, $nonce, $postStr, $decryptMsg);
		$postStr = $decryptMsg;

		$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
		$INFO_TYPE = trim($postObj->InfoType);

		//消息类型分离
		switch ($INFO_TYPE)
		{
			case "component_verify_ticket":
				$component_verify_ticket = $postObj->ComponentVerifyTicket;
				
				$num = $this->pdo->update("update wechat set component_verify_ticket='{$component_verify_ticket}' where id =2 ");
				
				//logger::loging('ticket_receive.log',"component_verify_ticket".PHP_EOL);
				break;
				
			case "authorized":
				//logger::loging('ticket.log',"authorized".PHP_EOL);
				break;
			
			case "unauthorized":
				//logger::loging('ticket.log',"unauthorized".PHP_EOL);
				break;	
			
			case "updateauthorized":
				//logger::loging('ticket.log',"updateauthorized".PHP_EOL);
				break;			
					
			default:
		
				break;
		}
		
		//全网发布要求3
		$result = 'success';
		
		echo $result;
		exit;
				
	}
	
	//轮询，获取第三方平台component_access_token,并保存至数据库，对接微信接口文档2
	public function get_component_access_token(){
			
		if ((time() > ($this->component_expires_time + 3600)) || (empty($this->component_access_token))){
            
			$component = array('component_appid' => $this->component_appid,'component_appsecret' => $this->component_appsecret,'component_verify_ticket' => $this->component_verify_ticket);
            
			$data = urldecode(json_encode($component));//还需要urldecode？
            
			$url = "https://api.weixin.qq.com/cgi-bin/component/api_component_token";
            
			$res = $this->http_request($url, $data);
            
			$result = json_decode($res, true);
            
			$this->component_access_token = $result["component_access_token"];
            
			$this->component_expires_time = time();
			
			$this->pdo->update("update wechat set component_expires_time = {$this->component_expires_time},component_access_token='{$this->component_access_token}' where id = 2 ");
            		
        }	
		
	}
	
	//获取预授权码pre_auth_code，对应微信接口3
    public function get_pre_auth_code()
    {
        $component = array('component_appid' => $this->component_appid);
        $data = urldecode(json_encode($component));
        $url = "https://api.weixin.qq.com/cgi-bin/component/api_create_preauthcode?component_access_token=".$this->component_access_token;
        $res = $this->http_request($url, $data);
        return json_decode($res, true);
    }
	
	
	//使用授权码换取公众号的接口调用凭据和授权信息,对应微信接口4
    public function query_authorization($auth_code)
    {
        $component = array('component_appid' => $this->component_appid,
                           'authorization_code' => $auth_code
                           );
        $data = urldecode(json_encode($component));
        $url = "https://api.weixin.qq.com/cgi-bin/component/api_query_auth?component_access_token=".$this->component_access_token;
        $res = $this->http_request($url, $data);
        return json_decode($res, true);
    }
	
	
	//获取授权方的公众号帐号基本信息,对应微信接口6
    public function get_authorizer_info($authorizer_appid)
    {
        $component = array('component_appid' => $this->component_appid,
                           'authorizer_appid' => $authorizer_appid
                           );
        $data = urldecode(json_encode($component));
        $url = "https://api.weixin.qq.com/cgi-bin/component/api_get_authorizer_info?component_access_token=".$this->component_access_token;
        $res = $this->http_request($url, $data);
        return json_decode($res, true);
    }
    
    //代发客服接口消息，用于微信全网发布检测
    public function send_custom_message($openid, $type, $data, $authorizer_access_token)
    {
        $msg = array('touser' =>$openid);
        $msg['msgtype'] = $type;
        switch($type)
        {
			//全网发布只走text。。。？
            case 'text':
                $msg[$type]    = array('content'=>urlencode($data));
                break;
            case 'news':
                $data2 = array();
                foreach ($data as &$item) {
                    $item2 = array();
                    foreach ($item as $k => $v) {
                        $item2[strtolower($k)] = urlencode($v);
                    }
                    $data2[] = $item2;
                }
                $msg[$type]    = array('articles'=>$data2);
                break;
            case 'music':
            case 'image':
            case 'voice':
            case 'video':
                $msg[$type]    = $data;
                break;
            default:
                $msg['text'] = array('content'=>urlencode("不支持的消息类型 ".$type));
                break;
        }
        $url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=".$authorizer_access_token;
        return $this->http_request($url, urldecode(json_encode($msg)));
    }

	//http请求
	public function http_request($url, $data = null)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)){
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);
		return $output;
	}
	
	
	//进行第3方平台的授权，公众号管理者要点击确认按钮，而且获取unionid还要第3方平台发二维码链接，用管理者的手机扫码（不是微信扫一扫）
	public function shouquan(){

		if (!isset($_GET["auth_code"])){
			$result = $this->get_pre_auth_code();
			$pre_auth_code = $result["pre_auth_code"];
			$redirect_uri = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$jumpurl = $this->component_login_page($pre_auth_code, $redirect_uri);
			//Header("Location: $jumpurl");
			include 'static'.DIRECTORY_SEPARATOR.'html'.DIRECTORY_SEPARATOR.'shouquan.html';
		}else{
			$authorization = $this->query_authorization($_GET["auth_code"]);
			
			$authorizer_appid = $authorization["authorization_info"]["authorizer_appid"];
			
			$authorizer_info = $this->get_authorizer_info($authorizer_appid);
			var_dump($authorizer_info);
			
		}
	
	}
	
	
	
}


?>