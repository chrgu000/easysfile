<?php

//以下是加载自定义配置文件
require '..'.DIRECTORY_SEPARATOR."setup".DIRECTORY_SEPARATOR."config.php";
require '..'.DIRECTORY_SEPARATOR."setup".DIRECTORY_SEPARATOR."database.php";
require '..'.DIRECTORY_SEPARATOR."setup".DIRECTORY_SEPARATOR."apierrorcode.php";

//composer的一小步，php学习路径的一大步
require '..'.DIRECTORY_SEPARATOR.'vendor/autoload.php';

use easys\web\response;
use easys\web\pdoobj;
use easys\web\oauth;
use easys\web\logger;



$str = bob_input($_SERVER['REQUEST_URI']);

$str = ltrim($str,'/');

//定义接收数组
$param = explode('/',$str);

//  '\\\'这里在【3个反斜杠】
if(preg_match('/[\t\n\f\v<>\\\]/',$str)){
	
	echo response::json(40001,$apierrorcode['40001']);

}elseif ($param[0]==='third'){
	
	$qiandao = "\\easys\\third\\";//表示加载前导类
	
	$objectname = $qiandao.$param[1];
	
	//param3为公众号传进来的appid
	$object = new $objectname($database['default'],$apierrorcode,$param[3]);
		
	//logger::loging('param.log',$param[3].PHP_EOL);	
		
	if(method_exists($object,$param[2])){
	
		$object->$param[2]();
	
	}else{
		
		echo response::json(40003,$apierrorcode['40003']);
		
	}
	
}elseif ($param[0]==='wechat'){
	
	$qiandao = "\\easys\\wechat\\";//表示加载前导类
	
	$objectname = $qiandao.$param[1];
	
	$object = new $objectname($database['default'],$apierrorcode);//创建api传进来的对象
		
	if(method_exists($object,$param[2])){
	
		$object->$param[2]();
	
	}else{
		
		echo response::json(40003,$apierrorcode['40003']);
		
	}
	
}else{
	
	echo response::json(40000,$apierrorcode['40000']);	

}










?>