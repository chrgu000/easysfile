<?php

namespace easys\web;

class logger
{

    public static function loging($filename,$word){
		
		$root = realpath($_SERVER['DOCUMENT_ROOT']);
		
		$file = $root.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'logs'.DIRECTORY_SEPARATOR.$filename;
		
		// 向文件追加写入内容
		// 使用 FILE_APPEND 标记，可以在文件末尾追加内容
		//  LOCK_EX 标记可以防止多人同时写入
		//file_put_contents($file, $site, FILE_APPEND | LOCK_EX);
		file_put_contents($file, $word, FILE_APPEND|LOCK_EX);
		
		if(filesize($file)>1024*1024*5){
		
			unlink($file);

		}	

    }
	
}


?>