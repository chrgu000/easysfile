<?php
namespace easys\web;

class pdoobj
{
    protected static $_instance = null;
    protected $dsn;
    protected $dbh;
    protected $stmt;
    /**
     * 构造
     * 
     * @return DAOPDO
     */
    private function __construct($dbHost, $dbUser, $dbPasswd, $dbName)
    {
        try {
            
            $this->dsn = 'mysql:host='.$dbHost.';dbname='.$dbName;
			
            $this->dbh = new \PDO($this->dsn, $dbUser, $dbPasswd,array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,\PDO::ATTR_PERSISTENT => false,\PDO::ATTR_STRINGIFY_FETCHES=>false,\PDO::ATTR_EMULATE_PREPARES=>false));
			
			$this->dbh->exec("SET character_set_connection='utf8mb4', character_set_results='utf8mb4', character_set_client=utf8mb4");

        } catch (PDOException $e) {
           
            die ("Error!: " . $e->getMessage() . "<br/>");
        }
    }
    
    /**
     * 防止克隆
     * 
     */
    private function __clone() {}
    
    /**
     * Singleton instance
     * 
     * @return Object
     */
    public static function getInstance($database)
    {
        if (self::$_instance === null) {
            self::$_instance = new self($database['hostname'], $database['username'], $database['password'], $database['database']);
        }
        return self::$_instance;
    }

    /**
     *
     * sql sql语句
     * array execute的数组[]
     * @return 2维数组
     */
    public function execall($sql,$array=[]){

    	$this->stmt = $this->dbh->prepare($sql);

		$this->stmt->execute($array);

		$result = $this->stmt->fetchAll(\PDO::FETCH_ASSOC);

    	return $result;
    	
    }

      /**
     *
     * sql sql语句
     * array execute的数组[]
     * @return 2维数组
     */
    public function update($sql,$array=[]){

    	$this->stmt = $this->dbh->prepare($sql);

		$this->stmt->execute($array);

    	return $this->stmt->rowCount(); 	
    	
    }
	
	   /**
     *
     * sql sql语句
     * array execute的数组[]
     * @return 2维数组
     */
    public function insert($sql,$array=[]){

    	$this->stmt = $this->dbh->prepare($sql);
		
		$this->stmt->execute($array);		

    	return $this->dbh->lastInsertId();
    	
    }
	

    /**
     * beginTransaction 事务开始
     */
    public function beginTransaction()
    {
        $this->dbh->beginTransaction();
    }
    
    /**
     * commit 事务提交
     */
    public function commit()
    {
        $this->dbh->commit();
    }
    
    /**
     * rollback 事务回滚
     */
    public function rollback()
    {
        $this->dbh->rollback();
    } 
   

    public function __destruct()
    {
    	$this->stmt = null;
    	$this->dbh = null;
    } 
 
}



?>