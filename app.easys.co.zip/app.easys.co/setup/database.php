<?php

$database = array (
	'default' => array (
		'hostname' => 'localhost',
		'port' => 3306,
		'database' => 'usefultest',
		'username' => 'root',
		'password' => 'root',
	)
);

?>