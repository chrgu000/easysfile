<?php

//以下设置编码为utf-8 
header("Content-type:text/html;charset=utf-8");

//以下是设置时区为中国时区
date_default_timezone_set('PRC');

//以下是注册错误处理函数
//set_error_handler(my_error_report);

function my_error_report($type,$mess,$file,$line){
    $str = "出错类型：".$type."<br>出错消息：".$mess."<br>出错文件".$file."<br>出错位置".$line;
    //将所有错误信息归类为异常
    //throw new Exception($str);   
}

?>